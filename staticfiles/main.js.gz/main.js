
// document.image.classList.add('fade');

// document.addEventListener("DOMContentLoaded", function (e) {
//     console.log('hello')
//     document.image.classList.remove('fade');
// });
